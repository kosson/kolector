Toate resursele editorului sunt ordonate aici: https://github.com/editor-js/awesome-editorjs

A fost creată o bibliotecă de parsing a obiectului pentru a genera HTML la https://github.com/MichaelMikeJones/editorjs-parser